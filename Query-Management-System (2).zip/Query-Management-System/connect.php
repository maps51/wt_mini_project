//<?php
//$conn=mysqli_connect("localhost","root","","quera") or die(mysqli_error($conn));
 //?>

<?php
session_start();
$servername = "localhost";
$username = "siddhi";
$password = "siddhi";

// Create connection
$conn = new mysqli($servername, $username, $password,"quera");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
