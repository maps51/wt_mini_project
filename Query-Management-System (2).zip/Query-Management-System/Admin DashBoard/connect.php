<?php
$conn=mysqli_connect("localhost","root","","quera") or die(mysqli_error($conn));
 ?>	