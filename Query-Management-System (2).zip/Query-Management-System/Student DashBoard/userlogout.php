<?php
//echo("Hi logged out !")
//include 'home.php';
session_start();
session_unset();
session_destroy();
header("location:http://localhost/Query-Management-System/login.php");
//include ('C:\xampp\htdocs\Query-Management-System\Index.html');
//include 'home.php';
exit();
?>
